---
layout: default
---

# Related Resources

Projects and resources related to Atomic Red Team.

* [Atomic Red Team Simple Parser](https://github.com/AlfredoAbarca/ARTSP)

