## Application Compatibility Shims

[Reference](https://blogs.technet.microsoft.com/askperf/2011/06/17/demystifying-shims-or-using-the-app-compat-toolkit-to-make-your-old-stuff-work-with-your-new-stuff/)

[Additional References:](https://sdb.tools/resources.html)

All Files Contained in .Zip.

Otherwise you can roll your own.

##### This Shim Injects a DLL named AtomicTest.DLL from C:\Tools into an Application named AtomicTest.exe
##### Specifically with an Original_FileName and Internal_Name of AtomicTest.exe
##### Easiest way to create that is to compile and use the C# Sample AtomicTest.cs
