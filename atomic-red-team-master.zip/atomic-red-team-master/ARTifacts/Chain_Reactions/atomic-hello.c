#include <stdio.h> 
 

//  Simple Hello World for Atomic Red Team payload

int main() { 
  
           printf("Hello from Atomic Red Team! \n"); 
               
           return 0; 
}