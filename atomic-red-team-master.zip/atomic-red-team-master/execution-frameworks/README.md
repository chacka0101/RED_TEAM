# Atomic Red Team Execution Frameworks
This repository will contain any lightweight execution frameworks that help you run Atomic Tests in your environment.