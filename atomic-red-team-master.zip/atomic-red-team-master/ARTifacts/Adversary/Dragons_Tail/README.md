### Group: Dragon's Tail
[Modeled After G0050](https://attack.mitre.org/wiki/Group/G0050)
